# Spotify react

App clone do spotify desenvolvido com o framework React.js para a disciplina de Desenvolvimento Web da unifor.
