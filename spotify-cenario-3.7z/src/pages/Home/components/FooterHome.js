import { Relogio } from "./Relogio";

export function FooterHome() {
  return (
    <footer>
      AMOSTRA DO SPOTIFY <Relogio></Relogio>
    </footer>
  );
}
